package com.mycom.maven_hibernate_crud;

import java.util.List;

public class App {
	public static void main(String[] args) {
		System.out.println("Hello, Hibernatre World!");
		IStudentDao studentDao = new StudentDao();

       // test saveStudent
       Student student = new Student("Mihira", "Kapoor", "mihira@gmail.com");
        studentDao.saveStudent(student);
        student=null;
     System.out.println("Student Data Inserted");

		/*
		 * // test updateStudent student.setFirstName("Ram");
		 * studentDao.updateStudent(student);
		 * 
		 * // test getStudentById Student student2 =
		 * studentDao.getStudentById(student.getId());
		 * 
		 * // test getAllStudents
		 */		
		List<Student> studentsList = studentDao.getAllStudents();
		for (Student tempStudent : studentsList) {
			System.out.println(tempStudent.getFirstName());
		}
		/*
		 * int student1=0; studentsList.forEach(student2 ->
		 * System.out.println(student2.getId()));
		 * 
		 * // test deleteStudent studentDao.deleteStudent(student.getId());
		 */

	}
}
